str = "//void* UpPetSkillLevel(void* et, int petguid, unsigned short skillid);\nkkkkkkkkkkk"
str = string.gsub(str,"(//[^\n]*)","") -- substitute 'void*'
print(str)
